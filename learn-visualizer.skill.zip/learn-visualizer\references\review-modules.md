# 复习模块设计模式

复习模块放在主动画区域下方，用来把“看懂”变成“记住、会区分、会做题”。

## 模块放置原则

```html
<!-- 主动画区 -->
<div class="animation-container">...</div>

<!-- 复习区 -->
<div class="review-container">
  <section class="review-module" id="module-overview">...</section>
  <section class="review-module" id="module-comparison">...</section>
</div>
```

For a lesson, chapter, or exam-review page, place overview and prerequisite modules before the animation. Review modules after the animation should convert understanding into recall, comparison, and question-answer ability.

## 1. 一句话结论卡

适用：任何知识点。

内容格式：

```text
这个知识点本质上是在讲：____。
最重要的逻辑是：____。
考试/应用时抓住：____。
```

## 2. 概念总览卡片

```css
.concept-card {
  background: linear-gradient(135deg, #f5f7fa, #c3cfe2);
  border-radius: 12px;
  padding: 20px 24px;
  margin: 12px 0;
}
.card-row {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 16px;
}
```

每张卡片建议只写：

```text
名称
一句话解释
它在整体中的作用
```

## 3. 对比表格

用于易混概念、相似结构、不同类型、不同步骤。

```css
.compare-table {
  width: 100%;
  border-collapse: collapse;
}
.compare-table th {
  background: #2c3e50;
  color: #fff;
  padding: 10px;
}
.compare-table td {
  padding: 8px 10px;
  border: 1px solid #ddd;
}
.compare-table .highlight-row {
  background: #fff3cd;
}
.focus-cell {
  background: #e8f4fd !important;
  font-weight: bold;
}
```

表格列推荐：

```text
概念 | 定义 | 关键词 | 作用 | 容易混淆点
```

## 4. 功能 / 作用卡片

适用：一个系统里多个部件各司其职。

```css
.func-card {
  border-left: 4px solid #3498db;
  padding: 12px 16px;
  margin: 8px 0;
  background: #f8f9fa;
}
```

内容格式：

```text
谁：____
做什么：____
结果：____
```

## 5. 易错点警示卡

```css
.pitfall-card {
  background: #fff5f5;
  border: 1px solid #fc8181;
  border-left: 5px solid #e53e3e;
  border-radius: 8px;
  padding: 14px 18px;
  margin: 10px 0;
}
.pitfall-card .title {
  color: #c53030;
  font-weight: bold;
}
```

易错点写法：

```text
错法：____。
为什么错：____。
正确记法：____。
```

## 6. 口诀 / 记忆钩子

只在真的有助于记忆时使用，不要硬编。

```css
.mnemonic-box {
  background: #edf2f7;
  border-radius: 10px;
  padding: 20px;
  text-align: center;
  font-size: 1.1em;
  line-height: 1.8;
}
```

## 7. 例题 / 应用题模块

适用：公式、判断题、流程题、工程计算、实验数据处理。

推荐结构：

```text
题目：____
第一步：找关键词。
第二步：套规则/公式。
第三步：得出结论。
```

## 8. 选择题测验

即时反馈，答案必须带解析。

Question count should match scope:

- Single concept: 2-4 questions.
- Lesson/section: 4-6 questions.
- Chapter/review: 6-10 questions.

Cover different question types instead of repeating the same row: definition, starting condition, sequence, comparison, function, exception, common mistake, and final result.

```javascript
function checkAnswer(btn, correct, explanation) {
  const feedback = btn.parentElement.parentElement.querySelector('.feedback');
  if (btn.dataset.value === correct) {
    btn.classList.add('correct');
    feedback.innerHTML = '✅ 正确：' + explanation;
    feedback.className = 'feedback correct-feedback';
  } else {
    btn.classList.add('wrong');
    feedback.innerHTML = '❌ 不对：' + explanation;
    feedback.className = 'feedback wrong-feedback';
  }
  btn.parentElement.querySelectorAll('.option-btn').forEach(b => b.disabled = true);
}
```

```css
.option-btn.correct { background: #c6f6d5; border-color: #38a169; }
.option-btn.wrong   { background: #fed7d7; border-color: #e53e3e; }
```

## 9. 标准答题句

当用户明显用于考试复习时添加。

格式：

```text
如果题目问“____”，可以答：____。
如果题目让比较“____和____”，可以从定义、作用、条件、结果四方面答。
```

For chapter/review pages, include one answer-ready paragraph that integrates the full topic. It should be short enough to memorize and broad enough to answer a "summarize this chapter" question.

## 10. 非考试场景的复习模块

如果不是考试，比如项目学习、工具学习、商业流程学习，则改成：

- 一页总结
- 操作清单
- 常见错误
- 场景案例
- 自测问题
