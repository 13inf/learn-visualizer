# Scope and Output Patterns

Choose the output pattern before designing the page. The same skill must work for a single confusing point, a whole lesson, a chapter review, or a reference-matching request across any subject.

## 1. Single Concept Animation

Use when the user gives one concept, one mechanism, one formula, one comparison, one process, or one problem-solving rule.

Primary goal: make one difficult idea understandable.

Recommended structure:

1. Title and one-sentence conclusion.
2. Learning goals.
3. Main animation or interactive diagram.
4. Step explanation panel.
5. Clickable nodes or reveal controls.
6. Compact review: key terms, common mistake, memory hook, 2-4 quiz questions.

Signals:

- "这个知识点"
- "帮我理解这个公式"
- "把这个流程做成动画"
- one paragraph of notes
- one table or one comparison pair

## 2. Lesson or Section Review

Use when the user gives several related subtopics under one section, a short lecture note, a small textbook excerpt, or a named section.

Primary goal: build a learning route, not only one animation.

Recommended structure:

1. Section title and route sentence.
2. Quick overview cards: what it is, why it matters, where it fits.
3. Component or term map.
4. Main animation for the central mechanism.
5. Table for distinctions, categories, conditions, or formulas.
6. Application/function cards.
7. Common mistakes.
8. Short self-test: 4-6 questions.

## 3. Chapter or Exam Review Page

Use when the user gives a chapter name, many headings, exam notes, or asks for full review.

Primary goal: create an interactive review handout. The animation is important, but it is not the whole page.

Recommended structure:

1. Strong title bar: "topic + review / animation / key points".
2. Overview module before the animation:
   - plain definition
   - intuitive explanation or analogy
   - system features / main route
3. Composition / naming / properties / prerequisites:
   - choose labels that fit the subject, such as "parts", "terms", "rules", "variables", "actors", "periods", or "steps"
4. Main animation:
   - show the central mechanism in enough detail for the scope
   - use 15-30 short nodes when the chapter has many linked steps
   - keep each node short; put details in tooltip, side panel, or popup
5. Live review panel:
   - highlight matching key points as animation nodes appear
   - connect the learner's visual attention to what they must remember
6. Core comparison table:
   - include the rows that test distinctions
   - highlight common rows, shared endpoints, exceptions, or formulas
7. Key-node focus modules:
   - give central hubs, decision points, bottlenecks, exception rules, formulas, or terminal outcomes their own cards
8. Functions / applications / consequences:
   - explain what the mechanism does in real scenarios or exam questions
9. Common mistakes:
   - write concrete wrong patterns, not vague warnings
10. Answer-ready summary:
   - include a paragraph or bullet set that can be reused in an exam, oral explanation, or practical checklist
11. Mnemonic only if helpful.
12. Quiz:
   - chapter scope usually needs 6-10 questions
   - cover definitions, distinctions, mechanisms, functions, exceptions, and terminal outcomes
   - every answer needs a short explanation

## 4. Reference-Matching Output

Use when the user provides an existing HTML page, screenshot, or says "I want this effect".

Do this before writing:

1. Inspect the reference artifact directly.
2. Identify its scope: single concept, lesson review, chapter review, tool, or presentation page.
3. Extract:
   - information architecture
   - first-screen priority
   - content density
   - animation model
   - review modules
   - quiz depth
   - mobile behavior
4. Match the learning structure and interaction intent first. Visual style comes second.
5. Do not copy a reference's subject-specific wording unless the new user's subject needs it.

Common lesson:

- A reference with overview cards, chapter sections, comparison tables, recitation summary, and many quiz questions is a full review page. Do not answer with only a centered animation.

## 5. Domain-Agnostic Naming

Never hard-code one discipline's labels. Translate the same slots into the user's domain:

- Biology/medicine: component, pathway, receptor, effect, regulation.
- Chemistry/food science: reactant, condition, step, product, function, error.
- Engineering/mechanics: part, force/input, constraint, transfer, output, failure mode.
- Math/statistics: variable, formula, condition, transformation, result, interpretation.
- Law/policy: actor, rule, condition, procedure, consequence, exception.
- History: actor, period, trigger, event, consequence, interpretation.
- Computer science: input, module, state, transition, output, edge case.

The page should feel native to the subject while keeping beginner-friendly explanation.

## 6. Minimum Coverage Rules

- Single concept: 1 main animation, 1 compact comparison or summary, 1-3 mistakes, 2-4 quiz questions.
- Lesson/section: 1 overview, 1 component/term map, 1 animation, 1 table, 3-5 mistakes, 4-6 quiz questions.
- Chapter/review: overview before animation, full mechanism or system map, comparison/classification table, key-node modules, answer-ready summary, 6-10 quiz questions.
- Reference match: coverage must be at least as broad as the reference unless the user asks for a simplified version.

