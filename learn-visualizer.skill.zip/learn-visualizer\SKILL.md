---
name: learn-visualizer
description: >
  Transform study content into a clear, interactive, single-file HTML learning page with zero external dependencies. Use for a single knowledge point, a lesson, a chapter, a course review unit, or messy notes across biology, chemistry, medicine, food science, engineering drawing, mechanics, electronics, math, history, law/policy, economics, computer science, language grammar, and other structured knowledge. The skill first classifies the requested scope, then builds either a focused concept animation or a complete review page with overview modules, interactive visualization, comparison tables, common mistakes, memorization/answer modules, and quizzes. Triggers include: "把这个知识点做成动画", "生成HTML帮我理解", "把这些笔记做成交互网页", "知识点可视化", "拆解这个知识点", "整章复习", "整节复习", "做复习动画", "做学习网页", "做讲解动画".
---

# Knowledge to Learning Animation

Turn dry or confusing knowledge into an interactive, self-contained HTML learning page. The page should help a learner understand **what it is, how it works, why it matters, how to distinguish it from similar ideas, and how to answer exam-style questions or practical review questions**.

This skill is **domain-agnostic**. Do not assume the topic is immunology, biology, or any single subject. Adapt the explanation and animation model to the user's actual content.

This skill is for ordinary learners. Do not design only for experts or one discipline. Use the user's source terms faithfully, but explain the structure in a way a motivated beginner can follow.

## Output Standard

Create one complete `.html` file unless the user explicitly asks for another format.

The HTML must be:

1. **Self-contained** — inline CSS + JS only; no external libraries, fonts, images, or network requests.
2. **Beginner-friendly** — explain from the learner's likely confusion point, not from expert terminology.
3. **Visually structured** — use nodes, arrows, cards, tables, timelines, panels, or formula blocks where useful.
4. **Interactive** — include at least one useful interaction: step replay, node click explanation, path switching, reveal answers, drag/compare, or quiz feedback.
5. **Review-ready** — include summary cards, comparison tables, common mistakes, memory hooks, and short quizzes when suitable.
6. **Faithful to source** — do not invent facts beyond the user's notes unless clearly marked as a simple explanation or common background.

## Scope First

Before choosing the visualization, classify the user's request:

- **Single concept / mechanism** — one definition, formula, rule, pathway, process, comparison, or difficult point. Build a focused concept animation first, then concise review modules.
- **Lesson / section / chapter / exam review** — words like "第几章", "整章", "整节", "本单元", "复习", "考点", or multiple headings/tables. Build a complete review page: overview first, then key components, then the main animation, then tables, mistakes, summary, and quizzes.
- **Reference-matching task** — the user provides a screenshot or HTML as "想要的效果". Inspect the reference before writing. Extract its information architecture, density, animation behavior, review modules, and mobile behavior; do not merely copy colors.
- **Existing HTML improvement** — preserve existing working animation and add modules around it unless the user asks for a redesign.

Read `references/scope-and-output-patterns.md` whenever the request is a lesson, chapter, review page, or reference-matching task.

## Universal Knowledge Decomposition Workflow

Before building the page, mentally decompose the user's content into these layers:

1. **Topic core** — What is the main knowledge point? Write a one-sentence plain-language definition.
2. **Learning goal** — What should the learner be able to do after seeing the page?
3. **Concept units** — Extract key terms, components, variables, actors, events, stages, formulas, rules, or categories.
4. **Relationships** — Identify sequence, cause-effect, part-whole, comparison, classification, condition-result, input-output, or formula dependency.
5. **Difficult point** — Find the part most likely to confuse a beginner. Turn this into the main animation focus.
6. **Scope pattern** — Decide whether this is a focused animation or a full review page.
7. **Visualization type** — Choose the best pattern from `references/visualization-archetypes.md`.
8. **Interaction design** — Decide what the learner can click, replay, reveal, compare, or test.
9. **Review modules** — Add summaries, comparison tables, pitfalls, mnemonics, standard answer lines, worked examples, or quiz questions according to the scope.

If the user gives messy notes, first organize them silently. The final page should be clean and structured, not a direct dump of the notes.

## Visualization Selection Rules

Use the knowledge structure to choose the animation:

- **Process / pathway / procedure** → step-by-step flow animation.
- **Structure / anatomy / machine part / object composition** → labeled diagram with clickable regions.
- **Classification / taxonomy / types** → branching tree or grouped cards.
- **Comparison / easily confused concepts** → side-by-side table plus highlight animation.
- **Cause and effect / mechanism** → chain reaction animation with trigger → process → outcome.
- **Formula / calculation / derivation** → formula breakdown with variable reveal and worked example.
- **Timeline / historical development / legal procedure** → horizontal timeline with event cards.
- **System interaction / network** → node-link graph with role-based colors.
- **Decision rules / diagnosis / problem solving** → decision tree or if-then flowchart.
- **Cycle / feedback loop** → circular diagram with replayable loop animation.

When multiple patterns fit, combine them. For a single concept, put the main animation early. For a chapter or review unit, put overview/context modules before the animation so the learner knows what the animation is explaining.

## Page Structure

Use `assets/template.html` as the starting skeleton.

Default single-concept structure:

1. **Title block** — topic name + one-sentence explanation.
2. **Learning goal strip** — "看完你要会：...".
3. **Main animation area** — nodes/arrows/SVG/cards/timeline/formula.
4. **Step explanation panel** — updates as the animation progresses.
5. **Click-to-explain details** — each important node/card should open a short explanation.
6. **Review area** — overview cards, comparison table, common mistakes, memory hook, quiz.

Chapter/review structure:

1. **Title bar** — name the unit and state the main learning route.
2. **Overview modules** — definition, plain-language analogy, composition/parts, naming/properties, or prerequisite ideas.
3. **Main animation + live review panel** — animate the core mechanism and highlight matching key points or summary items as the animation progresses.
4. **Comparison / classification / formula table** — make the most testable distinctions scannable.
5. **Key-node focus modules** — give important hubs, bottlenecks, decisions, or exceptions their own cards.
6. **Functions / applications / consequences** — explain what the system does after the mechanism.
7. **Common mistakes** — write concrete wrong answer patterns and the correct memory.
8. **Recitation / answer-ready summary** — provide a paragraph or bullets the learner can reuse.
9. **Quiz** — use enough questions to cover the full scope; a chapter usually needs 6-10, not 2-3.

## Language Rules

Default language follows the user's language. If the user writes Chinese, use Chinese.

For Chinese study pages:

- Use direct, exam-friendly phrasing.
- Prefer short sentences.
- Use "先看结论 → 再看过程 → 最后做题".
- For chapter/review pages, use "先搭框架 → 再看动画 → 再背考点 → 最后自测".
- Explain terms with everyday analogies only when they reduce confusion.
- Avoid decorative filler text.
- Important labels should be short enough to fit inside nodes.

For non-exam learning pages:

- Use plain explanations.
- Keep technical precision.
- Use examples and mini-checks instead of rote memorization.

## Core Technical Rules

### Node Positioning

```css
.node {
  position: absolute;
  transform: translate(-50%, -50%);
}
```

`left` and `top` represent the geometric center of the node. SVG coordinates should match these values directly.

### Canvas Scaling

Never resize by modifying every node coordinate. Use CSS scale:

```css
.diagram-wrap { transform: scale(1.1); transform-origin: top center; }
.diagram-wrap-outer { min-width: <scaled_width>px; }
```

### Step-by-Step Animation

Each frame must remove `dimmed` before adding `visible`:

```javascript
node.classList.remove('dimmed');
node.classList.add('visible');
```

Do not batch-clean `dimmed` after the animation ends, because `.node.dimmed { opacity: 0.18 !important }` overrides `.node.visible`.

### Tooltip

Always use `position: fixed` with `clientX/clientY`. Do not use `absolute` inside scaled or overflow containers.

### Existing HTML Modification

When enhancing an existing HTML page:

1. Read the full file.
2. Preserve the original animation and logic.
3. Add new modules below the animation container.
4. Append CSS/JS safely at the end of existing `<style>` and `<script>` blocks.
5. Do not rewrite the whole file unless the user explicitly requests a redesign.

### File Output

Write the final HTML to the working/output directory. Do not overwrite a user's original file without creating a backup or receiving explicit permission.

## Reference Files

- `references/decomposition-pipeline.md` — how to turn messy notes into animation-ready structure.
- `references/scope-and-output-patterns.md` — how to choose between focused animation, lesson review, chapter review, and reference-matching output.
- `references/visualization-archetypes.md` — which animation type to choose for different knowledge structures.
- `references/svg-patterns.md` — SVG path coordinates, arrows, canvas scaling.
- `references/interaction-patterns.md` — step reveal, click popups, tooltips, switching, formula reveal, timeline replay.
- `references/review-modules.md` — concept cards, comparison tables, common mistakes, mnemonics, quizzes.
- `references/pitfalls.md` — technical and learning-design mistakes to avoid.

## Quality Checklist

Before finalizing, verify:

- The page teaches the actual user-provided topic, not a generic template.
- The scope matches the user request: do not turn a chapter/review request into only a single mechanism animation.
- If the user provided a reference effect, the output matches its learning structure and interaction intent, not just its color.
- The hardest part is animated or visually emphasized.
- For review pages, overview modules appear before the animation and the animation is tied to review points.
- Every important term is either labeled, explained, or clickable.
- The animation order matches the real logic of the concept.
- Similar concepts are compared clearly.
- Common mistakes are included.
- Quiz coverage matches the scope and answers have explanations, not just right/wrong labels.
- The HTML runs offline as a single file.
