# 交互模式参考

这些交互适用于任何学科的知识动画。优先选择能帮助理解的交互，而不是只做装饰效果。

## 1. 逐帧亮起动画

适用：流程、反应链、操作步骤、时间顺序、推导步骤。

### 核心机制

初始所有节点 dimmed（半透明），动画逐帧将节点变亮并展示连线。

```css
.node.dimmed {
  opacity: 0.18 !important;
  pointer-events: none;
}
.node.visible {
  opacity: 1;
  pointer-events: auto;
  transition: opacity 0.5s ease;
}
```

### 逐帧展示函数

```javascript
async function animateSteps(steps) {
  dimAll();
  updateStepPanel('准备开始：先看整体，再看每一步。');

  for (let i = 0; i < steps.length; i++) {
    await sleep(600);

    const node = document.getElementById(steps[i].nodeId);
    if (node) {
      node.classList.remove('dimmed');
      node.classList.add('visible');
    }

    if (steps[i].edgeId) {
      const edge = document.getElementById(steps[i].edgeId);
      if (edge) edge.style.opacity = '1';
    }

    updateStepPanel(steps[i].text || '');
  }
}

function dimAll() {
  document.querySelectorAll('.node').forEach(n => {
    n.classList.add('dimmed');
    n.classList.remove('visible');
  });
}
```

关键陷阱：`.node.dimmed` 的 `!important` 会压制 `.node.visible` 的 `opacity`。逐帧亮起时必须先 `remove('dimmed')` 再加 `visible`。

## 2. 步骤解释面板

动画每走一步，面板同步显示“这一步发生了什么”。

```html
<div class="step-panel" id="step-panel">
  点击“播放”开始逐步理解。
</div>
```

```javascript
function updateStepPanel(text) {
  const panel = document.getElementById('step-panel');
  if (panel) panel.innerHTML = text;
}
```

面板内容建议：

```text
第1步：输入/起点是什么。
第2步：发生了什么变化。
第3步：为什么会进入下一步。
最后：得到什么结论。
```

## 3. Tooltip 悬停提示

使用 `fixed` 定位跟随鼠标，避免 `absolute` 在滚动/缩放容器中偏移。

```javascript
node.addEventListener('mousemove', (e) => {
  tooltip.innerHTML = html;
  tooltip.style.left = e.clientX + 15 + 'px';
  tooltip.style.top = e.clientY + 15 + 'px';
  tooltip.style.display = 'block';
});
node.addEventListener('mouseleave', () => {
  tooltip.style.display = 'none';
});
```

## 4. 点击弹窗

节点点击弹出短知识卡片。

```javascript
function openPopup(title, content) {
  const popup = document.getElementById('popup');
  const popupContent = document.getElementById('popup-content');
  popupContent.innerHTML = `<h3>${title}</h3><p>${content}</p>`;
  popup.style.display = 'block';
}
```

弹窗内容推荐固定为 3 部分：

```text
它是什么：一句话定义。
它的作用：在这个知识点里负责什么。
容易错：最容易混淆的地方。
```

## 5. 路径 / 模式切换按钮

适用：多条途径、多种类型、多种情况、多种解法。

```javascript
function setActiveButton(activeId) {
  document.querySelectorAll('.controls button').forEach(btn => {
    btn.classList.toggle('active', btn.id === activeId);
  });
}

document.getElementById('btn-mode-a').addEventListener('click', () => {
  resetAll();
  setActiveButton('btn-mode-a');
  animateSteps(modeASteps);
});
```

## 6. 公式逐步拆解

适用：数学、物理、化学、食品实验计算、工程制图尺寸计算。

```javascript
function revealFormulaPart(id, explanation) {
  document.getElementById(id).classList.add('formula-highlight');
  updateStepPanel(explanation);
}
```

推荐顺序：

1. 显示完整公式。
2. 逐个解释变量。
3. 代入一个简单例子。
4. 显示计算结果。
5. 解释结果在题目中代表什么。

## 7. 分类树展开

适用：分类知识、层级关系、概念体系。

```javascript
function toggleChildren(groupId) {
  document.querySelectorAll(`[data-parent="${groupId}"]`).forEach(el => {
    el.classList.toggle('hidden');
  });
}
```

## 8. 对比高亮

适用：易混概念。

```javascript
function highlightColumn(className) {
  document.querySelectorAll('.compare-table td, .compare-table th').forEach(cell => {
    cell.classList.remove('focus-cell');
  });
  document.querySelectorAll('.' + className).forEach(cell => {
    cell.classList.add('focus-cell');
  });
}
```

## 9. 测验即时反馈

```javascript
function checkAnswer(btn, correct, explanation) {
  const feedback = btn.parentElement.parentElement.querySelector('.feedback');
  if (btn.dataset.value === correct) {
    btn.classList.add('correct');
    feedback.innerHTML = '✅ 正确：' + explanation;
    feedback.className = 'feedback correct-feedback';
  } else {
    btn.classList.add('wrong');
    feedback.innerHTML = '❌ 不对：' + explanation;
    feedback.className = 'feedback wrong-feedback';
  }
  btn.parentElement.querySelectorAll('.option-btn').forEach(b => b.disabled = true);
}
```

## 10. 重置函数

切换模式或重播时必须清理干净。

```javascript
function resetAll() {
  document.querySelectorAll('.node').forEach(n => {
    n.classList.remove('dimmed', 'visible', 'active', 'focus');
  });
  document.querySelectorAll('.edge-layer path').forEach(e => e.style.opacity = '0');
  document.querySelectorAll('.formula-highlight').forEach(e => e.classList.remove('formula-highlight'));
  tooltip.style.display = 'none';
  const popup = document.getElementById('popup');
  if (popup) popup.style.display = 'none';
}
```
