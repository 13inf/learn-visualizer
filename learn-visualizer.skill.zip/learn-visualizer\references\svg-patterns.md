# SVG 连线与节点定位模式

## 节点定位标准做法

所有动画节点使用 `position: absolute` + `transform: translate(-50%, -50%)`，使 `left`/`top` 对应节点几何中心：

```css
.node {
  position: absolute;
  /* left/top 设置在节点应在的几何中心 */
  transform: translate(-50%, -50%);
}
```

这样计算 SVG 连线坐标时，直接取节点的 `left`/`top` 即可，无需额外偏移。

## 画布缩放策略

**禁止直接修改节点坐标来缩放画布。** 使用 CSS transform 包裹层：

```css
.diagram-wrap-outer {
  min-width: 1130px;  /* 缩放后的实际宽度 */
  min-height: 615px;  /* 缩放后的实际高度 */
}
.diagram-wrap {
  transform: scale(1.2);
  transform-origin: top center;
}
```

优势：所有节点坐标和 SVG 坐标保持不变，缩放仅由 CSS 处理；调整缩放比例只需改一个数字。

## SVG 连线坐标计算

SVG `path` 的 `d` 属性中，坐标必须与节点 `left`/`top` 精确对应。计算规则：

1. 起点 = 起始节点的 (left, top)
2. 终点 = 目标节点的 (left, top)
3. 贝塞尔曲线控制点根据连线方向设定偏移量

示例——从 A节点(500, 300) 到 B节点(650, 300) 的水平连线：
```
M 500 300 C 550 300, 600 300, 650 300
```

带直角转弯的连线，中间插入拐点坐标。

## 箭头标记 (marker-end)

```html
<defs>
  <marker id="arrowhead" markerWidth="10" markerHeight="7" 
          refX="10" refY="3.5" orient="auto">
    <polygon points="0 0, 10 3.5, 0 7" fill="#e74c3c" />
  </marker>
</defs>
<path d="..." stroke="#e74c3c" fill="none" marker-end="url(#arrowhead)" />
```

## 连线退化修复

当箭头不显示时检查：
1. `marker-end` 中的 `url(#id)` 与 `<marker id="...">` 是否匹配
2. `refX`/`refY` 是否在箭头尖端
3. 路径终点是否与箭头朝向一致
