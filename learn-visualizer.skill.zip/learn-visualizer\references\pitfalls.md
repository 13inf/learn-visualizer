# 常见陷阱与避坑指南

## 1. 不要把任何知识点都做成“流程图”

错误：用户给的是分类、结构、公式或对比内容，却硬做成从左到右的流程。

正确：先判断知识结构，再选择动画模型。

```text
分类 → 分类树
结构 → 标注图
公式 → 变量拆解
对比 → 对比表
因果 → 链条动画
流程 → 步骤动画
```

## 2. 不要只复制笔记文字

错误：把用户笔记原样塞进卡片，页面看起来很多字，但没有真正帮助理解。

正确：先拆解成：定义、组成、关系、步骤、易错点、题目问法。

## 3. 不要为了好看牺牲准确性

动画必须符合真实逻辑。

- 顺序不能错。
- 因果方向不能反。
- 包含关系不能画反。
- 对比概念不能偷换定义。
- 不确定内容不要编造。

## 4. 禁止正则批量替换 HTML 属性

致命错误：用 Python 正则缩放坐标时，`d="..."` 或 `id="..."` 等属性被误匹配。

```text
错误正则： (d)="([^"]+)" 
后果：匹配到 id="arrowhead" 中的 d，破坏 marker ID、path ID、node ID。
```

正确做法：绝不使用正则批量修改 HTML。坐标缩放改用 CSS `transform: scale()`；必须修改坐标时逐条手动调整。

## 5. dimmed 类与 visible 类冲突

`.node.dimmed` 使用 `opacity: 0.18 !important`，`.node.visible` 使用 `opacity: 1`。

错误：在动画全部播完后统一 remove dimmed，播放期间节点一直半透明。

正确：每个节点亮起时同步 `remove('dimmed')` + `add('visible')`。

```javascript
// ✅ 正确
node.classList.remove('dimmed');
node.classList.add('visible');

// ❌ 错误
function undimPathway() {
  document.querySelectorAll('.node').forEach(n => n.classList.remove('dimmed'));
}
```

## 6. Tooltip 定位偏移

在 `overflow: hidden`、`transform: scale()` 或嵌套滚动容器中，`absolute` 定位的 tooltip 会偏移。

解决：使用 `position: fixed` + `clientX/clientY`。

## 7. 动画重置不彻底

切换模式或重播时必须：

- 清理所有节点的 `dimmed`、`visible`、`active`、`focus` 类。
- 重置所有 SVG 连线的 `opacity` 为 0。
- 隐藏 tooltip 和弹窗。
- 清除公式高亮或表格高亮。
- 重置步骤解释面板。
- 清除未完成的 `setTimeout` 或动画队列。

## 8. 增量修改时误删已有结构

当用户要求在已有动画页面上增加模块时，禁止重写整个文件。必须：

1. 读取完整文件。
2. 找到主动画区边界。
3. 在动画区之后追加新模块。
4. 只新增必要 CSS/JS。
5. 不触碰原有动画逻辑。

## 9. 节点文字过长

错误：节点里塞一整句话，导致布局混乱。

正确：节点只放短标签，详细解释放 tooltip、弹窗或步骤面板。

```text
节点：关键步骤A
弹窗：它负责把输入条件转化为下一步结果，是整个过程的转折点。
```

## 10. 复习模块太泛

错误：只写“重点总结”“注意区分”，但没有具体内容。

正确：写出可背、可判断、可做题的内容。

```text
错法：A和B很相似，要注意区分。
正确：A强调____，B强调____；看到关键词____选A，看到关键词____选B。
```

## 11. 文件路径安全

产出物写入工作目录或 output 目录，不要覆盖用户桌面上的原始文件。用户明确要求“修改某文件”时，先备份再改。
